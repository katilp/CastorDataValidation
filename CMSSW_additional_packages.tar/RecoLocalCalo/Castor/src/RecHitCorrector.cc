// -*- C++ -*-
//
// Package:    RecHitCorrector
// Class:      RecHitCorrector
// 
/**\class RecHitCorrector RecHitCorrector.cc RecoLocalCalo/Castor/src/RecHitCorrector.cc

 Description: [one line class summary]

 Implementation:
     [Notes on implementation]
*/
//
// Original Author:  Hans Van Haevermaet
//         Created:  Wed Feb 23 11:29:43 CET 2011
// $Id: RecHitCorrector.cc,v 1.3 2011/05/13 13:20:14 hvanhaev Exp $
//
//


// system include files
#include <memory>

// user include files
#include "FWCore/Framework/interface/Frameworkfwd.h"
#include "FWCore/Framework/interface/EDProducer.h"

#include "FWCore/Framework/interface/Event.h"
#include "FWCore/Framework/interface/MakerMacros.h"
#include "FWCore/Framework/interface/ESHandle.h"
#include "FWCore/Framework/interface/EventSetup.h"

#include "FWCore/ParameterSet/interface/ParameterSet.h"

#include "DataFormats/HcalRecHit/interface/HcalRecHitCollections.h"

#include "CondFormats/CastorObjects/interface/CastorChannelQuality.h"
#include "CondFormats/CastorObjects/interface/CastorChannelStatus.h"
#include "CondFormats/DataRecord/interface/CastorChannelQualityRcd.h"

//
// class declaration
//

class RecHitCorrector : public edm::EDProducer {
   public:
      explicit RecHitCorrector(const edm::ParameterSet&);
      ~RecHitCorrector();

   private:
      virtual void beginJob() ;
      virtual void produce(edm::Event&, const edm::EventSetup&);
      virtual void endJob() ;
      
      // ----------member data ---------------------------
      edm::InputTag inputLabel_;
      bool isData_;
};

//
// constants, enums and typedefs
//


//
// static data member definitions
//

//
// constructors and destructor
//
RecHitCorrector::RecHitCorrector(const edm::ParameterSet& iConfig):
inputLabel_(iConfig.getParameter<edm::InputTag>("rechitLabel")),
isData_(iConfig.getParameter<bool>("isData"))
{
   //register your products
   produces<CastorRecHitCollection>();
   //now do what ever other initialization is needed
   std::cout << "Setting up the CASTOR RecHitCorrector, optimized for Comm2010 42X data and MC corrections that are input to 53X reconstruction code" << std::endl;
}


RecHitCorrector::~RecHitCorrector()
{
 
   // do anything here that needs to be done at desctruction time
   // (e.g. close files, deallocate resources etc.)

}


//
// member functions
//

// ------------ method called to produce the data  ------------
void
RecHitCorrector::produce(edm::Event& iEvent, const edm::EventSetup& iSetup)
{
   using namespace edm;
   
   // get original rechits
   edm::Handle<CastorRecHitCollection> rechits;
   iEvent.getByLabel(inputLabel_,rechits);

   // get conditions
   edm::ESHandle<CastorChannelQuality> p;
   iSetup.get<CastorChannelQualityRcd>().get(p);
   CastorChannelQuality* myqual = new CastorChannelQuality(*p.product());
   
   if (!rechits.isValid()) std::cout << "No valid CastorRecHitCollection found, please check the InputLabel..." << std::endl;
      
   std::auto_ptr<CastorRecHitCollection> rec(new CastorRecHitCollection);
   
   // Optimized for Comm2010 data that is partly intercalibrated (Comm2010 42X datasets)
   
   for (unsigned int i=0;i<rechits->size();i++) {
   	CastorRecHit rechit = (*rechits)[i];
	double fC = rechit.energy(); // in Comm10 42X data: energy = inter.cal. fC
	double time = rechit.time();
	//std::cout << "rechit energy(fC) = " << fC << " time = " << time << std::endl;
	
	double correctedenergy = 0;
	
	if (isData_) {
		// if data, do this:
		if (rechit.id().module() <= 2) {
			correctedenergy = 0.015*0.5*fC; // in Comm10 42X data, the EM response needs to be corrected + apply 0.015 GeV/fC abs. cal. factor to get GeV units
		} else {
			correctedenergy = 0.015*fC; // apply 0.015 GeV/fc abs. cal. factor to get GeV units
		}
		
	} else {
		// if MC, do this:
		correctedenergy = 0.015*(rechit.energy()/0.016); // correct the 42X MC energy scale (0.016) to correct for the 0.015 factor
	}
	
        // now check the channelquality of this rechit
	bool ok = true;
	DetId detcell=(DetId)rechit.id();
	std::vector<DetId> channels = myqual->getAllChannels();
	for (std::vector<DetId>::iterator channel = channels.begin();channel !=  channels.end();channel++) {	
		if (channel->rawId() == detcell.rawId()) {
			// if channel is present in the list, mark as bad
			ok = false;
			break;
		}
	}
        
        if (ok) {
	  CastorRecHit *correctedhit = new CastorRecHit(rechit.id(),correctedenergy,time);
	  rec->push_back(*correctedhit);
	  delete correctedhit;
	}
   }
   
   iEvent.put(rec);
   delete myqual;
 
}

// ------------ method called once each job just before starting event loop  ------------
void 
RecHitCorrector::beginJob()
{
}

// ------------ method called once each job just after ending the event loop  ------------
void 
RecHitCorrector::endJob() {
}

//define this as a plug-in
DEFINE_FWK_MODULE(RecHitCorrector);
