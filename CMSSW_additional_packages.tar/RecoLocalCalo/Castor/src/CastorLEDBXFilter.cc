// -*- C++ -*-
//
// Package:    CastorLEDBXFilter
// Class:      CastorLEDBXFilter
// 
/**\class CastorLEDBXFilter CastorLEDBXFilter.cc RecoLocalCalo/Castor/src/CastorLEDBXFilter.cc

 Description: [one line class summary]

 Implementation:
     [Notes on implementation]
*/
//
// Original Author:  local user
//         Created:  Mon May 20 2019
//
//


// system include files
#include <memory>

// user include files
#include "FWCore/Framework/interface/Frameworkfwd.h"
#include "FWCore/Framework/interface/EDFilter.h"

#include "FWCore/Framework/interface/Event.h"
#include "FWCore/Framework/interface/MakerMacros.h"

#include "FWCore/ParameterSet/interface/ParameterSet.h"


//
// class declaration
//

class CastorLEDBXFilter : public edm::EDFilter {
   public:
      explicit CastorLEDBXFilter(const edm::ParameterSet&);
      ~CastorLEDBXFilter();

      static void fillDescriptions(edm::ConfigurationDescriptions& descriptions);

   private:
      virtual void beginJob() ;
      virtual bool filter(edm::Event&, const edm::EventSetup&);
      virtual void endJob() ;
      
      virtual bool beginRun(edm::Run&, edm::EventSetup const&);
      virtual bool endRun(edm::Run&, edm::EventSetup const&);
      virtual bool beginLuminosityBlock(edm::LuminosityBlock&, edm::EventSetup const&);
      virtual bool endLuminosityBlock(edm::LuminosityBlock&, edm::EventSetup const&);

      // ----------member data ---------------------------
};

//
// constants, enums and typedefs
//

//
// static data member definitions
//

//
// constructors and destructor
//
CastorLEDBXFilter::CastorLEDBXFilter(const edm::ParameterSet& iConfig)
{
   //now do what ever initialization is needed

}


CastorLEDBXFilter::~CastorLEDBXFilter()
{
 
   // do anything here that needs to be done at desctruction time
   // (e.g. close files, deallocate resources etc.)

}


//
// member functions
//

// ------------ method called on each new Event  ------------
bool
CastorLEDBXFilter::filter(edm::Event& iEvent, const edm::EventSetup& iSetup)
{
   using namespace edm;

   bool badbx = false;
   // filter out LED contaminated colliding BXs in bad runs
   if ( (iEvent.id().run() >= 142265 && iEvent.id().run() <= 142422) || (iEvent.id().run() >= 143179 && iEvent.id().run() <= 144114) ) {
      int iBX = iEvent.bunchCrossing();
	  if (iBX == 151 || iBX == 1215 || iBX == 1375 || iBX == 1906 || iBX == 2386 || iBX == 2971 || iBX == 3130) badbx = true;
	  if (iBX == 41 || iBX == 201 || iBX == 361 || iBX == 521 || iBX == 3021) badbx = true;
	  // filter out LED contaminated bunches in single beams
	  if (iBX == 895 || iBX == 1055 || iBX == 1535 || iBX == 1695) badbx = true;
   }

   // return if OK
   return !badbx;
}

// ------------ method called once each job just before starting event loop  ------------
void 
CastorLEDBXFilter::beginJob()
{
}

// ------------ method called once each job just after ending the event loop  ------------
void 
CastorLEDBXFilter::endJob() {
}

// ------------ method called when starting to processes a run  ------------
bool 
CastorLEDBXFilter::beginRun(edm::Run&, edm::EventSetup const&)
{ 
  return true;
}

// ------------ method called when ending the processing of a run  ------------
bool 
CastorLEDBXFilter::endRun(edm::Run&, edm::EventSetup const&)
{
  return true;
}

// ------------ method called when starting to processes a luminosity block  ------------
bool 
CastorLEDBXFilter::beginLuminosityBlock(edm::LuminosityBlock&, edm::EventSetup const&)
{
  return true;
}

// ------------ method called when ending the processing of a luminosity block  ------------
bool 
CastorLEDBXFilter::endLuminosityBlock(edm::LuminosityBlock&, edm::EventSetup const&)
{
  return true;
}

// ------------ method fills 'descriptions' with the allowed parameters for the module  ------------
void
CastorLEDBXFilter::fillDescriptions(edm::ConfigurationDescriptions& descriptions) {
  //The following says we do not know what parameters are allowed so do no validation
  // Please change this to state exactly what you do use, even if it is no parameters
  edm::ParameterSetDescription desc;
  desc.setUnknown();
  descriptions.addDefault(desc);
}
//define this as a plug-in
DEFINE_FWK_MODULE(CastorLEDBXFilter);
