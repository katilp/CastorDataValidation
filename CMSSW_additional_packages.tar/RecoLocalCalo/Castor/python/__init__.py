#Automatically created by SCRAM
import os
__path__.append(os.path.dirname(os.path.abspath(__file__).rsplit('/RecoLocalCalo/Castor/',1)[0])+'/cfipython/slc5_amd64_gcc434/RecoLocalCalo/Castor')
