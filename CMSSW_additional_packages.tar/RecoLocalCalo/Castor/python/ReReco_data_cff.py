import FWCore.ParameterSet.Config as cms

# import Castor tower and jet reconstruction
from RecoLocalCalo.Castor.Castor_cff import *

# construct the module which executes the RechitCorrector
rechitcorrector = cms.EDProducer("RecHitCorrector",
       rechitLabel = cms.InputTag("castorreco","","RECO"), # choose the original RecHit collection
       isData = cms.bool(True) # perform 42X data corrections for 53X RECO input
)

# tell to the CastorTower reconstruction that he should use the new corrected rechits
CastorTowerReco.inputprocess = "rechitcorrector"

# add extra CastorJet collections
from RecoJets.JetProducers.ak5CastorJets_cfi import *
from RecoJets.JetProducers.ak5CastorJetID_cfi import *

CastorReReco = cms.Sequence(rechitcorrector*CastorFullReco*ak5BasicJets*ak5CastorJetID)
